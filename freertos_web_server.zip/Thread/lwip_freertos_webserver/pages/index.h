const static char http_index_page_html[] =
	"<html><body><h1> form </h1>"
	"<form action=\"index.html\">"
	"<input type=\"hidden\" name=\"setled0\" value=\"false\">"
	"<input type=\"hidden\" name=\"setled1\" value=\"false\">"
	"<input type=\"checkbox\"  name=\"setled0\" value=\"true\">set on blue<br/>"
	"<input type=\"checkbox\"  name=\"setled1\" value=\"true\">set on green<br/>"
	"<input type=\"checkbox\"  name=\"blink0\" value=\"true\">blink blue<br/>"
	"<input type=\"checkbox\"  name=\"blink1\" value=\"true\">blink green<br/>"
	"<input type=\"submit\" value=\"Submit\"></form><br/>"
	"</body></html>";


/*
* @brief	Netconn implementation that gets data from filesystem
*
* @note
* Copyright(C) NXP Semiconductors, 2013
* All rights reserved.
*
* @par
* Software that is described herein is for illustrative purposes only
* which provides customers with programming information regarding the
* LPC products.  This software is supplied "AS IS" without any warranties of
* any kind, and NXP Semiconductors and its licensor disclaim any and
* all warranties, express or implied, including all implied warranties of
* merchantability, fitness for a particular purpose and non-infringement of
* intellectual property rights.  NXP Semiconductors assumes no responsibility
* or liability for the use of the software, conveys no license or rights under any
* patent, copyright, mask work right, or any other intellectual property rights in
* or to any products. NXP Semiconductors reserves the right to make changes
* in the software without notification. NXP Semiconductors also makes no
* representation or warranty that such application will be suitable for the
* specified use without further testing or modification.
*
* @par
* Permission to use, copy, modify, and distribute this software and its
* documentation is hereby granted, under NXP Semiconductors' and its
* licensor's relevant copyrights in the software, without fee, provided that it
* is used in conjunction with NXP Semiconductors microcontrollers.  This
* copyright, permission, and disclaimer notice must appear in all copies of
* this code.
*/

#include <stdio.h>
#include <string.h>
#include "lwip/opt.h"
#include "lwip/arch.h"
#include "lwip/api.h"
#include "lwip_fs.h"
#include "index.h"
#include <stdlib.h>

#define LWIP_HTTPD_DYNAMIC_HEADERS 1
#include "httpd_structs.h"

#if LWIP_NETCONN

#ifndef HTTPD_DEBUG
#define HTTPD_DEBUG         LWIP_DBG_OFF
#endif

// FIXME - needs standards formatting
extern QueueHandle_t global_queue;
/* Default file content incase a valid filesystem is not present */
const static char http_html_hdr[] = "HTTP/1.1 200 OK\r\nContent-type: text/html\r\n\r\n";
const static char http_index_html[] = 
	"<html><head><title>Congrats!</title></head><body>"
	"<h1>Welcome to our lwIP FreeRTOS HTTP server!"
	"</h1><p>This is a small test page, served by httpserver-netconn.</body></html>";

/* Dynamic header generation based on Filename */
extern int GetHTTP_Header(const char *fName, char *buff);
void http_server_netconn_init(void);

#ifndef CRLF
#define CRLF "\r\n"
#endif

/* Function to check if the requested method is supported */
static int supported_method(const char *method)
{
	if (strncmp(method, "GET", 3) == 0)
		return 1;
	if (strncmp(method, "POST", 4) == 0)
		return 1;
	return 0;
}

void *vLED0_set(void *parameter) {
	Board_LED_Set(0, true);
}

void *vLED1_set(void *parameter) {
	Board_LED_Set(1, true);
}
void *vLED0_reset(void *parameter) {
	Board_LED_Set(0, false);
}
void *vLED1_reset(void *parameter) {
	Board_LED_Set(1, false);
}


void *vLED0_blink(void *parameter) {
	bool LedState = false;
	int i =0;
	while (i<20) {
		//taskYIELD();
		Board_LED_Set(0, LedState);
		LedState = (bool) !LedState;

		/* About a 3Hz on/off toggle rate */
		vTaskDelay(configTICK_RATE_HZ / 6);
		i++;
	}
	Board_LED_Set(0, false);
}

void *vLED1_blink(void *parameter) {
	bool LedState = false;
	int i =0;
	while (i<20) {
		//taskYIELD();
		Board_LED_Set(1, LedState);
		LedState = (bool) !LedState;

		/* About a 3Hz on/off toggle rate */
		vTaskDelay(configTICK_RATE_HZ / 6);
		i++;
	}
	Board_LED_Set(1, false);
}


/* Function to extract version information from URI */
static uint32_t get_version(const char *vstr)
{
	int major = 0, minor = 0;
	sscanf(vstr, "HTTP/%d.%d", &major, &minor);
	return (major << 16) | minor;
}

/** Serve one HTTP connection accepted in the http thread */
static void
http_server_netconn_serve(struct netconn *conn)
{
  struct netbuf *inbuf;
  char *buf, *tbuf,*tbuf2;
  char *page;
  char *par,par_name[10],*par_val;
  void *(*msg)();
  uint8_t i;
  u16_t buflen;
	struct fs_file *fs = NULL;
  err_t err;
	static uint8_t file_buffer[1024];
	int len;
	uint32_t req_ver;

  /* Read the data from the port, blocking if nothing yet there.
   We assume the request (the part we care about) is in one netbuf */
  err = netconn_recv(conn, &inbuf);

  if (err != ERR_OK) return;

	netbuf_data(inbuf, (void**)&buf, &buflen);
	buf[buflen]='\0';
	if (buflen < 5 || strstr(buf, CRLF) == NULL) {
		//LWIP_DEBUGF(HTTPD_DEBUG, ("HTTPD: Invalid Request Line\r\n"));
		printf("invalid request\n");
		goto close_and_exit;
	}

	//LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("HTTPD: Got URI %s\r\n", buf));
	//-----debug lorenzo
	printf("HTTPD: Got URI\n");
	//-----
	tbuf = strchr(buf, ' ');
	if (tbuf == NULL) {
		//LWIP_DEBUGF(HTTPD_DEBUG, ("HTTPD: Parse error in Request Line\r\n"));
		printf("parse error\n");
		goto close_and_exit;
	}

	*tbuf++ = 0;
	if (!supported_method(buf)) {
		//LWIP_DEBUGF(HTTPD_DEBUG, ("HTTPD: Un-supported method: %s\r\n", buf));
		printf("unsupported method\n");
		goto close_and_exit;
	}
	buf = tbuf;
	tbuf = strchr(buf, ' ');
	if (tbuf == NULL) {
		//LWIP_DEBUGF(HTTPD_DEBUG, ("HTTPD: Version string not found: %s\r\n", buf));
		printf("version string not found\n");
	} else {
		*tbuf++ = 0;
		req_ver = get_version(tbuf);
		//LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("HTTPD: Request version %d.%d\r\n",
		//	req_ver >> 16, req_ver & 0xFFFF));
	}

	tbuf = strchr(buf, '?');
	if (tbuf != NULL) {
		tbuf++;
		//pars ready

		par = strtok(tbuf,"&");
		while(par!=NULL){
			//computation
			i=0;
			while(par[i]!='='){
				par_name[i] = par[i];
				i++;
			}
			par_name[i]='\0';
			//par_name = (char *) malloc(sizeof(char)*i);
			//memset(par_name,0,sizeof(char)*i);
			//memcpy(par_name,par,sizeof(char)*i);
			par_val = &(par[i+1]);//strchr(par,'=');
			//par_val++;
			//printf("\n\nname = %s\nval = %s\n\n",par_name,par_val);
			if(strcmp(par_name,"setled0")==0){
				if(strcmp(par_val,"true")==0)
					msg=&vLED0_set;
				else// if(strcmp(par_val,"false")==0)
					msg=&vLED0_reset;
			}
			else if(strcmp(par_name,"setled1")==0){
				if(strcmp(par_val,"true")==0)
					msg=&vLED1_set;
				else //if(strcmp(par_val,"false")==0)
					msg=&vLED1_reset;
			}
			else if(strcmp(par_name,"blink0")==0){
				if(strcmp(par_val,"true")==0)
					msg=&vLED0_blink;
			}
			else if(strcmp(par_name,"blink1")==0){
				if(strcmp(par_val,"true")==0)
					msg=&vLED1_blink;
			}
			//free(par_name);
			xQueueSend(global_queue,&msg,portMAX_DELAY);
			par = strtok(NULL,"&");

		}
		//*tbuf++ = 0;

	}
	if (strlen(buf) == 1 && *buf == '/') {
		/*fs = fs_open("/pene.html");
		if (fs == NULL)
			fs = fs_open("pene.html");
		if (fs == NULL) {
			/* No home page, send if from buffer */
      netconn_write(conn, http_html_hdr, sizeof(http_html_hdr)-1, NETCONN_NOCOPY);
      netconn_write(conn, http_index_page_html, sizeof(http_index_page_html)-1, NETCONN_NOCOPY);
			goto close_and_exit;

	} else {
		//fs = fs_open(buf);
		/*if(strcmp(buf,"/welcome.html")){
			netconn_write(conn, http_html_hdr, sizeof(http_html_hdr)-1, NETCONN_NOCOPY);
			netconn_write(conn, http_welcome_page_1_html, sizeof(http_welcome_page_1_html)-1, NETCONN_NOCOPY);
			netconn_write(conn,tbuf,strlen(tbuf),NETCONN_NOCOPY);
			netconn_write(conn, http_welcome_page_2_html, sizeof(http_welcome_page_2_html)-1, NETCONN_NOCOPY);
		*/
	 //if(strcmp(buf,"index.html")){
		 netconn_write(conn, http_html_hdr, sizeof(http_html_hdr)-1, NETCONN_NOCOPY);
		 netconn_write(conn, http_index_page_html, sizeof(http_index_page_html)-1, NETCONN_NOCOPY);
		 goto close_and_exit;
	//	}
	}
	/*if (fs == NULL) {
		int len;
		LWIP_DEBUGF(HTTPD_DEBUG, ("HTTPD: Unable to open file[%s]\r\n", buf));
		len = GetHTTP_Header(NULL, (char *)file_buffer);
		netconn_write(conn, file_buffer, len, NETCONN_NOCOPY);
		goto close_and_exit;
	}*/

	/***
	 * FIXME: There is a possible race condition while accessing
	 *        file_buffer, must use a mutex to protect it.
	 **/
	//if (fs->http_header_included)
		/* Send the header */
	/*	netconn_write(conn, fs->data, fs->index, NETCONN_NOCOPY);*/

	 /* Read the file now */
	/* while ((len = fs_read(fs, (char *)file_buffer, sizeof(file_buffer))) > 0) {
		netconn_write(conn, file_buffer, len, NETCONN_NOCOPY);
	 }*/

close_and_exit:
  //fs_close(fs);
  /* Close the connection (server closes in HTTP) */
  netconn_close(conn);

  /* Delete the buffer (netconn_recv gives us ownership,
   so we have to make sure to deallocate the buffer) */
  netbuf_delete(inbuf);
}

/** The main function, never returns! */
static void
http_server_netconn_thread(void *arg)
{
  struct netconn *conn, *newconn;
  err_t err;
  LWIP_UNUSED_ARG(arg);

  /* Create a new TCP connection handle */
  conn = netconn_new(NETCONN_TCP);
  LWIP_ERROR("http_server: invalid conn", (conn != NULL), return;);

  /* Bind to port 80 (HTTP) with default IP address */
  netconn_bind(conn, NULL, 80);

  /* Put the connection into LISTEN state */
  netconn_listen(conn);

  do {
    err = netconn_accept(conn, &newconn);
    if (err == ERR_OK) {
			/* Push the remote IP info to other Core */
			ip_addr_t remote_ip;
			u16_t port_num;
			err = netconn_getaddr(newconn, &remote_ip, &port_num, 0);

      http_server_netconn_serve(newconn);
      netconn_delete(newconn);
    }
  } while(err == ERR_OK);
  printf("http_server_netconn_thread: netconn_accept received error %d, shutting down\n",err);
  netconn_close(conn);
  netconn_delete(conn);
}

/*********************************************************************//**
 * @brief	Blinky Initialization function
 *
 * This function is called by the common dual-core init,
 * which will start the HTTP server and will serve requests received.
 *
 * @return	None
 **********************************************************************/
void
http_server_netconn_init(void)
{
#if (!defined(BOARD_HITEX_EVA_4350) && !defined(BOARD_HITEX_EVA_1850))
	/* Initialize the file system */
	//fs_init();
#endif
	sys_thread_new("http_server_netconn", http_server_netconn_thread, NULL, DEFAULT_THREAD_STACKSIZE , DEFAULT_THREAD_PRIO);
	printf("init end\n");
}

#endif /* LWIP_NETCONN*/







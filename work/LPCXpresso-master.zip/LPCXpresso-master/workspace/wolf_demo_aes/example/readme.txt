AES example

Example description
This example illustrates the use of ECB and CBC modes of encryption decryption with and without DMA.
Three types of keys can be used - Software key( user defined) , Random key from RNG 
and AES keys in the OTP.

Target board LPC43S37 Xpresso board
The board communicates to the PC terminal through UART0.

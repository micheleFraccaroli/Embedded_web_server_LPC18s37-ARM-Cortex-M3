LWIP no-RTOS TCP Echo example

Example description
This example demonstrates the use of Clock APIs to control the CGU settings.  This example uses UART
console to print the outputs.

Special connection requirements
There are no special connection requirements for this example.

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
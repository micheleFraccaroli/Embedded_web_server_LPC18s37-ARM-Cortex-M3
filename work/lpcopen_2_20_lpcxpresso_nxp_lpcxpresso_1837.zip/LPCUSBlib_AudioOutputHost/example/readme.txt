USB Audio Output host example

Example Description
This example shows how to use the USB host stack to implement USB audio output
class. This example generates audio samples using (PWM timer) and will play it
when an USB speaker is connected to USB0 host port, after a button is pressed
on the board.

Connection requirements
USB speaker connected to the USB host port 0.

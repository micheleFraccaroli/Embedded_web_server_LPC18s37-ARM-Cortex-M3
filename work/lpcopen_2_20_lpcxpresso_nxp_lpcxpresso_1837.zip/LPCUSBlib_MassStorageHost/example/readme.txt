USB Keyboard Host example

Example Description
This example shows how to use the USB host stack to implement USB keyboard
class. This example will print the keys pressed in a connected USB keyboard
to an UART console.

Connection requirements
A USB keyboard device to be connected to the USB0 host port. Open terminal
program, connect UART and configure for baud 115200, 8-bits and 1 stopbit
